export default class BaseService {}
