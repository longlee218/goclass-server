export default class BaseController {}
