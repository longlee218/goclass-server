export const _401 = 'Unauthorized';
export const _404 = 'Not found';
export const _403 = 'Forbidden';
export const _500 = 'Server error';
export const _200 = 'Ok';
export const _201 = 'Created';
export const _204 = 'No content';
